﻿using Microsoft.AspNetCore.Mvc;
using QuickBooksIntegration.Model;
using QuickBooksIntegration.Interfaces;
using QuickBooksIntegration.Services;
using Microsoft.IdentityModel.Tokens;
using Microsoft.Extensions.Caching.Distributed;

namespace QuickBooksApi.Controller
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly ITokenService _tokenService;
        private readonly IDistributedCache _cache;

        public AuthController(ConfigClassModels config, ITokenService tokenService , IDistributedCache cache)
        {
            _tokenService = tokenService;
            _cache = cache;
        }
        public enum ErrorMessages
        {
            Please_Connect_Again,
            Invalid_Refresh_Token
        }

        [HttpGet("get-connectionlink")]
        public async Task<IActionResult> GetConnectLink()
        {
            try
            {
                string authorizeUrl = await _tokenService.GetAuthorizationURL();
                return Ok(authorizeUrl);
            }
            catch (Exception ex)
            {
                return NotFound(new ApiResponseModel
                {
                    IsSuccess = false,
                    Message = ex.Message,
                    ErrorType = ex.GetType().Name
                });
            }
        }


        [HttpGet("callback")]
        public async Task<IActionResult> GetAuthTokens(string code, string realmId)
        {
            try
            {
                var tokenResponseValues = await _tokenService.GetAuthTokensAsync(code);
                return Ok(tokenResponseValues);
            }
            catch (Exception ex)
            {
                return NotFound(new ApiResponseModel
                {
                    IsSuccess = false,
                    Message = ex.Message,
                    ErrorType = ex.GetType().Name
                });
            }
        }

        //[HttpPost("get-refresh-accesstoken")]
        //public async Task<IActionResult> RefreshAccessToken(string refreshToken)
        //{
        //    try
        //    {

        //        var refreshTokenTime = _tokenService.AccessToken.RefreshTokenExpiresIn;
        //        // min -> hrs -> days
        //        var days = ((refreshTokenTime / 60) / 60) / 24;
        //        var refreshTokenExpirationDate = DateTime.Now.AddDays(days);

        //        if (refreshTokenExpirationDate <= DateTime.UtcNow)
        //        {
        //            return NotFound(new ApiResponseModel
        //            {
        //                IsSuccess = false,
        //                Message = ErrorMessages.Please_Connect_Again.ToString(),
        //            });
        //        }

        //        var tokenResponseValues = await _tokenService.RefreshAccessTokenAsync(refreshToken);
        //        if (tokenResponseValues == null)
        //        {
        //            return NotFound(new ApiResponseModel
        //            {
        //                IsSuccess = false,
        //                Message = ErrorMessages.Invalid_Refresh_Token.ToString(),
        //            });
        //        }
        //        return Ok(tokenResponseValues);
        //    }
        //    catch (Exception ex)
        //    {
        //        return NotFound(new ApiResponseModel
        //        {
        //            IsSuccess = false,
        //            Message = ex.Message,
        //            ErrorType = ex.GetType().Name
        //        });
        //    }

        //}

    }
}

