﻿using Intuit.Ipp.Data;
using Intuit.Ipp.OAuth2PlatformClient;
using Microsoft.Extensions.Caching.Distributed;
using QuickBooksIntegration.Interfaces;
using QuickBooksIntegration.Model;
using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc;

namespace QuickBooksIntegration.Services
{
    public class TokenService : ITokenService
    {
        private readonly OAuth2Client _auth2Client;
        public readonly ConfigClassModels _config;
        private static string _redirectUrl;
        private readonly IDistributedCache _cache;
        public  TokenResponseValues _AccessToken;

        public enum ErrorMessages
        {
            Please_Connect_Again,
            Invalid_Refresh_Token
        }

        public TokenService(ConfigClassModels config, IDistributedCache cache)
        {
            _config = config;
            _redirectUrl = string.Format(_config.RedirectUrl, _config.ApplicationUrl);
            _auth2Client = new Intuit.Ipp.OAuth2PlatformClient.OAuth2Client(_config.ClientId, _config.ClientSecret, _redirectUrl, _config.Environment);
            _cache = cache;
        }
        public TokenResponseValues AccessToken
        {
            get { return _AccessToken; }
        }

        public async Task<string> GetAuthorizationURL()
        {
            List<OidcScopes> scopes = new List<OidcScopes>
            {
                OidcScopes.Accounting,
                OidcScopes.Payment
            };
            return  _auth2Client.GetAuthorizationURL(scopes);    
        }

        public async Task<TokenResponseValues> GetAuthTokensAsync(string code)
        {
            var tokenResponse = await _auth2Client.GetBearerTokenAsync(code);

            var tokenResponseValues = new TokenResponseValues
            {
                AccessToken = tokenResponse.AccessToken,
                AccessTokenExpiresIn = tokenResponse.AccessTokenExpiresIn,
                RefreshToken = tokenResponse.RefreshToken,
                RefreshTokenExpiresIn = tokenResponse.RefreshTokenExpiresIn,
                IdToken = tokenResponse.IdentityToken
            };
            tokenResponseValues.RefreshAccessTokenExpirationTime();

            _AccessToken = tokenResponseValues;
            var tokenResponseValuesBytes = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(tokenResponseValues));
            var cacheEntryOptions = new DistributedCacheEntryOptions()
            {
                AbsoluteExpiration = DateTimeOffset.Now.Add(TimeSpan.FromMinutes(tokenResponseValues.AccessTokenExpiresIn))
            };

            await _cache.SetAsync(tokenResponseValues.CacheKey, tokenResponseValuesBytes, cacheEntryOptions);


            return tokenResponseValues;
        }

        public async Task<dynamic> RefreshAccessTokenAsync(string refreshToken)
        {
            var tokenResponse = await _auth2Client.RefreshTokenAsync(refreshToken);
            if (tokenResponse.AccessToken == null)
            {
                return null;
            }

            var tokenResponseValues = new TokenResponseValues
            {
                AccessToken = tokenResponse.AccessToken,
                AccessTokenExpiresIn = tokenResponse.AccessTokenExpiresIn,
                RefreshToken = tokenResponse.RefreshToken,
                RefreshTokenExpiresIn = tokenResponse.RefreshTokenExpiresIn
            };
            tokenResponseValues.RefreshAccessTokenExpirationTime();
            _AccessToken = tokenResponseValues;
            return tokenResponseValues;
        }


        public async Task<bool> IsAccessTokenExpiredAsync()
        {
            if (_AccessToken != null)
            {
                var tokenResponseValuesBytes = await _cache.GetAsync(_AccessToken.CacheKey);

                var tokenResponseValues = JsonSerializer.Deserialize<TokenResponseValues>(Encoding.UTF8.GetString(tokenResponseValuesBytes));

                return tokenResponseValues.AccessTokenExpirationTime < DateTime.Now;
            }
            return false;
        }

        public async Task<bool> IsRefreshTokenExpired(string refreshToken)
        {
            if (_AccessToken != null)
            {
                var refreshTokenTime = _AccessToken.RefreshTokenExpiresIn;
                // min -> hrs -> days
                var days = ((refreshTokenTime / 60) / 60) / 24;
                var refreshTokenExpirationDate = DateTime.Now.AddDays(days);

                if (refreshTokenExpirationDate <= DateTime.UtcNow)
                {
                    return true;
                }
            }
            return false;
        }

    }
}
