﻿using QuickBooksIntegration.Model;

namespace QuickBooksIntegration.Interfaces
{
    public interface ITokenService
    {
        Task<string> GetAuthorizationURL();
        Task<TokenResponseValues> GetAuthTokensAsync(string code);
        Task<dynamic> RefreshAccessTokenAsync(string refreshToken);
        Task<bool> IsAccessTokenExpiredAsync();
        TokenResponseValues AccessToken { get; }
        Task<bool> IsRefreshTokenExpired(string refreshToken);
    }
}
