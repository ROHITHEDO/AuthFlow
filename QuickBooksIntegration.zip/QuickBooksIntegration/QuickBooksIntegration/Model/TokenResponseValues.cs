﻿
namespace QuickBooksIntegration.Model
{
    public class TokenResponseValues
    {
        public string AccessToken { get; set; }
        public long AccessTokenExpiresIn { get; set; }
        public string RefreshToken { get; set; }
        public long RefreshTokenExpiresIn { get; set; }
        public string IdToken { get; set; }

        public DateTime AccessTokenExpirationTime { get; set; }
        public string CacheKey { get { return $"{AccessToken}|{RefreshToken}"; } }

        public void RefreshAccessTokenExpirationTime()
        {
            AccessTokenExpirationTime = DateTime.Now.AddSeconds(AccessTokenExpiresIn);
        }
    }
}
