﻿
namespace QuickBooksIntegration.Model
{
    public class ApiResponseModel
    {
        public bool IsSuccess { get; set; }
        public string? Message { get; set; }
        public object? Data { get; set; }
        public string? ErrorType { get; set; }
    }
}
