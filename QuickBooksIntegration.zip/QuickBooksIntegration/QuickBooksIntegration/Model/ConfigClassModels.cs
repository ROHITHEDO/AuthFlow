﻿using Microsoft.Extensions.Configuration;

namespace QuickBooksIntegration.Model
{
    public class ConfigClassModels
    {
        public ConfigClassModels(IConfiguration configuration)
        {
            ClientId = configuration["AuthConfiguration:ClientId"];
            ClientSecret = configuration["AuthConfiguration:ClientSecret"];
            RedirectUrl = configuration["AuthConfiguration:RedirectUrl"];
            Scope = configuration["AuthConfiguration:Scope"];
            Environment = configuration["AuthConfiguration:Environment"];
            ApplicationUrl = configuration["AuthConfiguration:ApplicationUrl"];
        }
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
        public string RedirectUrl { get; set; }
        public string Scope { get; set; }
        public string Environment { get; set; }
        public string ApplicationUrl { get; set; }
    }
}
