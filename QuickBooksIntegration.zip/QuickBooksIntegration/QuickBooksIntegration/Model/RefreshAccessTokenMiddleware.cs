﻿using Microsoft.AspNetCore.Builder.Extensions;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using System.Text;
using QuickBooksIntegration.Interfaces;
using Microsoft.Extensions.Caching.Distributed;
using static QuickBooksIntegration.Services.TokenService;
using Microsoft.IdentityModel.Tokens;
using System.Text.Json;
using System.IdentityModel.Tokens.Jwt;
using Newtonsoft.Json.Linq;
using Microsoft.AspNetCore.Razor.Language.Intermediate;
using Newtonsoft.Json;

namespace QuickBooksIntegration.Model
{
    public class RefreshAccessTokenMiddleware
    {
        public readonly ITokenService _tokenService;
        private readonly RequestDelegate _next;
        private TokenResponseValues tokenResponseValues;
        private readonly IDistributedCache _cache;
        private TokenResponseValues _AccessToken;

        public RefreshAccessTokenMiddleware(RequestDelegate next, ITokenService tokenService, IDistributedCache cache)
        {
            _tokenService = tokenService;
            _next = next;
            _cache = cache;

        }

        public async Task InvokeAsync(HttpContext context)
        {
            if (await _tokenService.IsAccessTokenExpiredAsync())
            {
                var refreshToken = _tokenService.AccessToken.RefreshToken;

                //Check whther our refreshToken is expired or not
                if (await _tokenService.IsRefreshTokenExpired(refreshToken))
                {
                    context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                    context.Response.ContentType = "text/plain";
                    await context.Response.WriteAsync(ErrorMessages.Please_Connect_Again.ToString());
                    context.Abort();
                    return;

                }

                //Getting new Token
                var newTokenResponseValues = await _tokenService.RefreshAccessTokenAsync(refreshToken.ToString());
                _tokenService.AccessToken.RefreshAccessTokenExpirationTime();
                _AccessToken = newTokenResponseValues;

                context.Response.ContentType = "application/json";
                context.Response.StatusCode = StatusCodes.Status200OK;
                var json = System.Text.Json.JsonSerializer.Serialize(newTokenResponseValues);
                string message = JsonConvert.SerializeObject(json);
                await context.Response.WriteAsync(message);
                return;
                
            }

            await _next(context);
        }


    }
    public static class MyMiddlewareExtensions
    {
        public static IApplicationBuilder UseMyMiddleware(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<RefreshAccessTokenMiddleware>();
        }
    }
}
